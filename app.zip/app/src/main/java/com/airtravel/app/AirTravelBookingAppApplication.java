package com.airtravel.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AirTravelBookingAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(AirTravelBookingAppApplication.class, args);
	}

}
